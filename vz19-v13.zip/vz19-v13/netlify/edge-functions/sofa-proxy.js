/**
 * VZ-19 — Netlify Edge Function proxy Sofascore
 * Tourne sur le réseau edge Deno (pas bloqué par Sofascore)
 */
export default async (request, context) => {
  const url = new URL(request.url);
  const sofaPath = url.searchParams.get("path");

  const corsHeaders = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    "Content-Type": "application/json"
  };

  if (request.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  if (!sofaPath || !sofaPath.startsWith("/api/v1/")) {
    return new Response(JSON.stringify({ error: "Paramètre ?path manquant" }), {
      status: 400, headers: corsHeaders
    });
  }

  try {
    const response = await fetch(`https://api.sofascore.com${sofaPath}`, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.6167.144 Mobile Safari/537.36",
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "fr-FR,fr;q=0.9",
        "Origin": "https://www.sofascore.com",
        "Referer": "https://www.sofascore.com/",
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-site"
      }
    });

    const data = await response.text();
    return new Response(data, {
      status: response.status,
      headers: corsHeaders
    });

  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500, headers: corsHeaders
    });
  }
};

export const config = { path: "/sofa-proxy" };
