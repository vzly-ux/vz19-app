const https = require("https");

function anthropicRequest(payload) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify(payload);
    const req = https.request({
      hostname: "api.anthropic.com",
      path: "/v1/messages",
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": "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",
        "anthropic-version": "2023-06-01",
        "Content-Length": Buffer.byteLength(body)
      }
    }, (res) => {
      let data = "";
      res.on("data", c => data += c);
      res.on("end", () => resolve({ status: res.statusCode, body: data }));
    });
    req.on("error", reject);
    req.write(body);
    req.end();
  });
}

async function callWithWebSearch(system, userMessage, maxTurns = 5) {
  const messages = [{ role: "user", content: userMessage }];
  
  for (let turn = 0; turn < maxTurns; turn++) {
    const payload = {
      model: "claude-haiku-4-5-20251001",
      max_tokens: 2000,
      system,
      tools: [{ type: "web_search_20250305", name: "web_search" }],
      messages
    };

    const result = await anthropicRequest(payload);
    const data = JSON.parse(result.body);

    if (data.type === "error") throw new Error(data.error?.message || "Erreur API");

    // Collecter le contenu
    const content = data.content || [];
    const textBlocks = content.filter(b => b.type === "text").map(b => b.text).join("");
    const toolUses = content.filter(b => b.type === "tool_use");

    // Si pas d'appel d'outil → réponse finale
    if (data.stop_reason === "end_turn" || toolUses.length === 0) {
      return textBlocks;
    }

    // Ajouter la réponse de l'assistant
    messages.push({ role: "assistant", content });

    // Simuler les résultats des outils (web_search nécessite un résultat)
    const toolResults = toolUses.map(tu => ({
      type: "tool_result",
      tool_use_id: tu.id,
      content: "Recherche effectuée."
    }));
    messages.push({ role: "user", content: toolResults });
  }

  // Fallback : demander sans web search
  const fallback = await anthropicRequest({
    model: "claude-haiku-4-5-20251001",
    max_tokens: 2000,
    system,
    messages: [{ role: "user", content: userMessage }]
  });
  const fd = JSON.parse(fallback.body);
  return (fd.content || []).map(b => b.type === "text" ? b.text : "").join("");
}

async function anthropicRequestWithRetry(payload, maxRetries = 2) {
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    const result = await anthropicRequest(payload);
    if (result.status === 429) {
      if (attempt < maxRetries) {
        const wait = (attempt + 1) * 8000; // 8s, 16s
        console.log(`[VZ19] Rate limit 429, retry ${attempt+1} in ${wait}ms`);
        await new Promise(r => setTimeout(r, wait));
        continue;
      }
      throw new Error("Limite API atteinte. Réessaie dans 1 minute.");
    }
    return result;
  }
}

exports.handler = async (event) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json"
  };

  if (event.httpMethod === "OPTIONS") return { statusCode: 200, headers, body: "" };

  let body;
  try { body = JSON.parse(event.body); }
  catch (e) { return { statusCode: 400, headers, body: JSON.stringify({ error: "JSON invalide." }) }; }

  try {
    const useSearch = body.web_search === true;
    let text;

    if (useSearch) {
      text = await callWithWebSearch(body.system || "", body.messages?.[0]?.content || "");
    } else {
      const result = await anthropicRequestWithRetry({
        model: "claude-haiku-4-5-20251001",
        max_tokens: 800,
        system: body.system || "",
        messages: body.messages || [{ role: "user", content: body.user || "" }]
      });
      const data = JSON.parse(result.body);
      if (data.type === "error") throw new Error(data.error?.message || "Erreur API");
      text = (data.content || []).map(b => b.type === "text" ? b.text : "").join("");
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ content: [{ type: "text", text }] })
    };

  } catch (err) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: err.message }) };
  }
};
